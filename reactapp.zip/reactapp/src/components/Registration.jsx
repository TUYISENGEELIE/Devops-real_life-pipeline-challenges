import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Registration = () => {
    const [registration, setRegistration] = useState([]);
    const [message, setMessage] = useState('');
    const [isEditing, setIsEditing] = useState(false);

    const [form, setForm] = useState({
        RegisterID: '',
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        age: '',
        gender: '',
        country: '',
        city: '',
    });

    const fetchRegistration = () => {
        fetch('http://localhost:5000/register/register')
            .then(res => res.json())
            .then(data => {
                setRegistration(data);
                setMessage('Registrations loaded successfully.');
            })
            .catch(err => {
                console.error('Error:', err);
                setMessage('Failed to fetch registrations.');
            });
    };

    useEffect(() => {
        fetchRegistration();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: value }));
    };

    const resetForm = () => {
        setForm({
            RegisterID: '',
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            age: '',
            gender: '',
            country: '',
            city: '',
        });
        setIsEditing(false);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const url = isEditing
            ? `http://localhost:5000/register/update/${form.RegisterID}`
            : 'http://localhost:5000/register/all';

        const method = isEditing ? 'PUT' : 'POST';

        fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(form)
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to submit');
                return res.text(); // or .json() based on your backend
            })
            .then(() => {
                setMessage(isEditing ? 'Registration updated.' : 'Registration added.');
                fetchRegistration();
                resetForm();
            })
            .catch(err => {
                console.error('Error submitting form:', err);
                setMessage('Error occurred during submission.');
            });
    };

    const handleEdit = (registration) => {
        if (!window.confirm(`Edit registration ID ${registration.RegisterID}?`)) return;
        setForm(registration);
        setIsEditing(true);
    };

    const handleDelete = (id) => {
        if (!window.confirm(`Are you sure you want to delete registration ID ${id}?`)) return;

        fetch(`http://localhost:5000/register/delete/${id}`, {
            method: 'DELETE'
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to delete');
                setMessage(`Registration ${id} deleted.`);
                fetchRegistration();
            })
            .catch(err => {
                console.error('Delete error:', err);
                setMessage('Error deleting registration.');
            });
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <header style={{ backgroundColor: '#2c3e50', padding: '12px 0' }}>
                <nav>
                    <ul style={{
                        listStyle: 'none',
                        display: 'flex',
                        justifyContent: 'center',
                        margin: 0,
                        padding: 0,
                        gap: '12px',
                        flexWrap: 'wrap'
                    }}>
                        {['Home', 'About', 'Task', 'User', 'Registration', 'Login'].map((label, index) => (
                            <li key={index}>
                                <Link
                                    to={`/${label.trim().toLowerCase()}`}
                                    style={{
                                        color: 'white',
                                        backgroundColor: 'red',
                                        padding: '10px 18px',
                                        borderRadius: '5px',
                                        textDecoration: 'none',
                                        display: 'inline-block',
                                        fontWeight: 'bold'
                                    }}
                                >
                                    {label}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>
            </header>

            <main className="container mx-auto px-4 py-10">
                <div style={{
                    maxWidth: '600px',
                    margin: 'auto',
                    backgroundColor: '#fff9c4',
                    padding: '2em',
                    borderRadius: '10px',
                    boxShadow: '0 4px 10px rgba(0,0,0,0.1)'
                }}>
                    <h2 style={{ textAlign: 'center', marginBottom: '2em' }}>Registration Form</h2>
                    <p style={{ textAlign: 'center', color: 'green' }}>{message}</p>
                    <form onSubmit={handleSubmit}>
                        {[
                            { label: 'Register ID', name: 'RegisterID', type: 'number', disabled: isEditing },
                            { label: 'First Name', name: 'firstName' },
                            { label: 'Last Name', name: 'lastName' },
                            { label: 'Email', name: 'email', type: 'email' },
                            { label: 'Phone', name: 'phone', type: 'tel' },
                            { label: 'Age', name: 'age', type: 'number' },
                            { label: 'Country', name: 'country' },
                            { label: 'City', name: 'city' },
                        ].map(({ label, name, type = 'text', disabled = false }) => (
                            <div key={name} style={{ marginBottom: '10px' }}>
                                <label>{label}</label><br />
                                <input
                                    type={type}
                                    name={name}
                                    value={form[name]}
                                    onChange={handleChange}
                                    disabled={disabled}
                                    style={{
                                        width: '100%',
                                        padding: '8px',
                                        border: '1px solid #ccc',
                                        borderRadius: '4px'
                                    }}
                                />
                            </div>
                        ))}

                        <div style={{ marginBottom: '10px' }}>
                            <label>Gender:</label><br />
                            <select
                                name="gender"
                                value={form.gender}
                                onChange={handleChange}
                                style={{
                                    width: '100%',
                                    padding: '8px',
                                    border: '1px solid #ccc',
                                    borderRadius: '4px'
                                }}
                            >
                                <option value="">Select</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <button
                            type="submit"
                            style={{
                                width: '100%',
                                padding: '10px',
                                backgroundColor: '#fdd835',
                                color: '#333',
                                fontWeight: 'bold',
                                border: 'none',
                                borderRadius: '4px',
                                marginTop: '10px',
                                cursor: 'pointer'
                            }}
                        >
                            {isEditing ? 'Update Registration' : 'Submit'}
                        </button>
                    </form>
                </div>

                <div style={{
                    maxWidth: '1000px',
                    margin: '30px auto',
                    backgroundColor: '#fffde7',
                    border: '1px solid #ccc',
                    borderRadius: '8px',
                    padding: '1em',
                    overflowX: 'auto'
                }}>
                    <h2 style={{ marginBottom: '10px' }}>All Devops Registrations</h2>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead style={{ backgroundColor: 'blue', color: 'white' }}>
                            <tr>
                                {['Reg ID', 'First', 'Last', 'Email', 'Phone', 'Age', 'Gender', 'Country', 'City', 'Action'].map((head, i) => (
                                    <th key={i} style={{ padding: '8px', border: '1px solid #ddd' }}>{head}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {registration.length > 0 ? (
                                registration.map((item, idx) => (
                                    <tr key={idx}>
                                        <td>{item.RegisterID}</td>
                                        <td>{item.firstName}</td>
                                        <td>{item.lastName}</td>
                                        <td>{item.email}</td>
                                        <td>{item.phone}</td>
                                        <td>{item.age}</td>
                                        <td>{item.gender}</td>
                                        <td>{item.country}</td>
                                        <td>{item.city}</td>
                                        <td>
                                            <button onClick={() => handleEdit(item)} style={{ marginRight: '5px' }}>Edit</button>
                                            <button onClick={() => handleDelete(item.RegisterID)}>Delete</button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="10" style={{ textAlign: 'center' }}>No  Devops registrations available</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    );
};

export default Registration; 
