import React from "react";
import { Link } from "react-router-dom";

const About = () => {
  return (<div className="min-h-screen bg-gray-50">
    {/* Navigation Header */}
    <header style={{ backgroundColor: 'blue', padding: '10px 0' }}>
      <nav>
        <ul
          style={{
            listStyle: 'none',
            display: 'flex',
            justifyContent: 'center',
            margin: 0,
            padding: 0,
          }}
        >
          {['Dashbord', 'About', 'Task', 'User', 'Registration', 'Login'].map((label, index) => (
            <li
              key={index}
              style={{
                margin: '0 10px',
                border: '2px solid white',
                backgroundColor: 'red',
                borderRadius: '5px',
              }}

            >
              <Link
                to={`/${label.trim().toLowerCase()}`}
                style={{
                  color: 'black',
                  textDecoration: 'none',
                  padding: '10px 20px',
                  display: 'inline-block',
                }}
              >
                {label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>

    {/* Main Content */}
    <main className="container mx-auto px-4 py-10 text-center">
      <h1 className="text-4xl font-bold mb-8">About Devops Real-life pipeline challenges</h1>

      <img
        src="/iii.png"

        alt="Kawunga Flour"
        className="w-full max-h-[400px] object-cover rounded-xl mb-10"
      />

      <section className="mb-10 text-left max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-3">projects  Description</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>Devops Real-life pipeline challenges is focused how to improve morden developments
            in real_word
          </li>

        </ul>
      </section>

      <section className="mb-10 text-left max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-3">Main Activities</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>improvind devops papeline</li>
          <li>Procesing life into news technologies</li>
          <li>increasing automationsntechnicals in real-word</li>
        </ul>
      </section>

      <section className="mb-10 text-left max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-3">projects Structure</h2>
        <p>
          created by TUYISENGE ELIE with the partnership  ICT CHAMBER from
          digital talents programs, this projects enhancing  and addressing pipeline problems, .
        </p>
      </section>


      <section className="mb-10 text-left max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-3">Clients & Customers</h2>
        <p>
          Our target is  to improve  health-conscious consumers, local supporters, and
          sustainability advocates. We sell both online and in physical stores.
        </p>
      </section>

      <section className="mb-10 text-left max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-3">projects  Goals</h2>
        <p>
          Our goal is to ensure  security reliability, life sured,life improvements into mordern technology and support local economies through
          sustainable developments
        </p>
      </section>
    </main>
  </div>
  );
};

export default About; 