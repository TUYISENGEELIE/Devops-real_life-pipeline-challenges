import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const User = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [telephone, setTelephone] = useState('');

    const handleFirstName = (evt) => setFirstName(evt.target.value);
    const handleLastName = (evt) => setLastName(evt.target.value);
    const handleTelephone = (evt) => setTelephone(evt.target.value);

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log({ firstName, lastName, telephone });
    };

    return (
        <div className="container">
            <h2>User Form</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="firstName">First Name:</label>
                <input type="text" id="firstName" value={firstName} onChange={handleFirstName} /><br />
                <label htmlFor="lastName">Last Name:</label>
                <input type="text" id="lastName" value={lastName} onChange={handleLastName} /><br />
                <label htmlFor="telephone">Telephone:</label>
                <input type="text" id="telephone" value={telephone} onChange={handleTelephone} /><br />
                <Link to="/Task">submit</Link>
            </form>


        </div>
    );
};

export default User;
