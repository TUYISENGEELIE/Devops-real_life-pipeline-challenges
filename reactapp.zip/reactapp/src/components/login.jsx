import React, { useState } from 'react';
import { Link } from 'react-router-dom';



const Login = () => {

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('')


    const handleUsername = (evt) => {
        setUsername(evt.target.value)
    }
    const handlePassword = (evt) => {
        setPassword(evt.target.value)
    }
    const handlelogin = (event) => {

        event.preventDefault()

        console.form({
            username: username,
            password: password,


        })
    }



    return (<div className="container">
        <header style={{ backgroundColor: '#2c3e50', padding: '10px 0' }}>
            <nav>
                <ul
                    style={{
                        listStyle: 'none',
                        display: 'flex',
                        justifyContent: 'center',
                        margin: 0,
                        padding: 0,
                    }}
                >
                    {['Home', 'About', 'Task', 'User', 'Registration', 'Login'].map((label, index) => (
                        <li
                            key={index}
                            style={{
                                margin: '0 10px',
                                border: '2px solid white',
                                backgroundColor: 'red',
                                borderRadius: '5px',
                            }}
                        >
                            <Link
                                to={`/${label.trim().toLowerCase()}`}
                                style={{
                                    color: 'white',
                                    textDecoration: 'none',
                                    padding: '10px 20px',
                                    display: 'inline-block',
                                }}
                            >
                                {label}
                            </Link>
                        </li>
                    ))}
                </ul>
            </nav>
        </header>


        <h1>login Form</h1>

        <label for="username">Username:</label>
        <input type="text" id="username" name="Username" value={username} onChange={handleUsername} /><br />
        <label for="password">Password:</label>
        <input type="password" id="password" name="Password" value={password} onChange={handlePassword} /><br />
        <Link to="/Home">submit</Link>


    </div>

    )

}

export default Login;