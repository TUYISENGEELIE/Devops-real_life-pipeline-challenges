import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
    return (
        <div className="min-h-screen bg-gray-50">
            {/* Navigation Header */}
            <header style={{ backgroundColor: '#2c3e50', padding: '10px 0' }}>
                <nav>
                    <ul
                        style={{
                            listStyle: 'none',
                            display: 'flex',
                            justifyContent: 'center',
                            margin: 0,
                            padding: 0,
                        }}
                    >
                        {['Dashbord', 'About', 'Task', 'User', 'Registration', 'Login'].map((label, index) => (
                            <li
                                key={index}
                                style={{
                                    margin: '0 10px',
                                    border: '2px solid white',
                                    backgroundColor: 'red',
                                    borderRadius: '5px',
                                }}
                            >
                                <Link
                                    to={`/${label.trim().toLowerCase()}`}
                                    style={{
                                        color: 'white',
                                        textDecoration: 'none',
                                        padding: '10px 20px',
                                        display: 'inline-block',
                                    }}
                                >
                                    {label}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>
            </header>


        </div>
    );
};

export default Dashbord;
