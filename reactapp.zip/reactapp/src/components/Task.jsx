import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Task = () => {
    const [taskList, setTaskList] = useState([]);
    const [message, setMessage] = useState('');
    const [taskID, setTaskID] = useState('');
    const [taskFName, setTaskFName] = useState('');
    const [taskLName, setTaskLName] = useState('');
    const [description, setDescription] = useState('');
    const [isEditing, setIsEditing] = useState(false);

    const fetchTask = () => {
        fetch('http://localhost:5000/tasks/task')
            .then(res => res.json())
            .then(data => {
                setTaskList(data);
                setMessage('Tasks loaded successfully.');
            })
            .catch(err => {
                console.error('Fetch error:', err);
                setMessage('Record failed to loading .');
            });
    };

    useEffect(() => {
        fetchTask();
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        const taskData = {
            TaskID: parseInt(taskID),
            TaskFName: taskFName,
            TaskLName: taskLName,
            Description: description
        };

        const method = isEditing ? 'PUT' : 'POST';
        const url = isEditing
            ? `http://localhost:5000/tasks/update/${taskData.TaskID}`
            : 'http://localhost:5000/tasks/insert';

        fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(taskData)
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to save task');
                return res.json();
            })
            .then(() => {
                setMessage(isEditing ? 'Task updated successfully.' : 'Task added successfully.');
                resetForm();
                fetchTask();
            })
            .catch(err => {
                console.error('Error saving task:', err);
                setMessage('Failed to save task.');
            });
    };

    const resetForm = () => {
        setTaskID('');
        setTaskFName('');
        setTaskLName('');
        setDescription('');
        setIsEditing(false);
    };

    const handleEdit = (task) => {
        setTaskID(task.TaskID);
        setTaskFName(task.TaskFname);
        setTaskLName(task.TaskLname);
        setDescription(task.Description);
        setIsEditing(true);
    };

    const handleDelete = (id) => {
        if (!window.confirm('Are you sure you want to delete this task?')) return;

        fetch(`http://localhost:5000/tasks/delete/${id}`, {
            method: 'DELETE'
        })
            .then(res => {
                if (!res.ok) throw new Error('Delete failed');
                setMessage(`Task with ID ${id} deleted.`);
                fetchTask();
            })
            .catch(err => {
                console.error('Delete error:', err);
                setMessage('Error deleting task.');
            });
    };

    const inputStyle = {
        width: '100%',
        padding: '8px',
        marginBottom: '10px',
        border: '1px solid #ccc',
        borderRadius: '5px'
    };

    return (
        <div style={{ minHeight: '100vh', backgroundColor: '#fffbea' }}>
            {/*  Navigation Header */}
            <header style={{ backgroundColor: '#FFFF00', padding: '12px 0' }}>
                <nav>
                    <ul style={{
                        listStyle: 'none',
                        display: 'flex',
                        justifyContent: 'center',
                        margin: 0,
                        padding: 0,
                        gap: '12px',
                        flexWrap: 'wrap'
                    }}>
                        {['Home', 'About', 'Task', 'User', 'Registration', 'Login'].map((label, index) => (
                            <li key={index}>
                                <Link
                                    to={`/${label.trim().toLowerCase()}`}
                                    style={{
                                        color: 'black',
                                        backgroundColor: 'red',
                                        padding: '10px 18px',
                                        borderRadius: '5px',
                                        textDecoration: 'none',
                                        display: 'inline-block',
                                        fontWeight: 'bold'
                                    }}
                                >
                                    {label}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </nav>
            </header>

            {/* Main Content */}
            <div
                style={{
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', padding: '2em'
                }}
            >
                <h1 style={{ marginBottom: '1em' }}>Devops Management Systems</h1>

                <div style={{ overflow: 'hidden', marginBottom: '20px' }}>
                    <img
                        src="/New Template-Photoroom.PNG"
                        alt="Task Banner"
                        style={{ width: '250px', height: '100px', objectFit: 'cover', borderRadius: '8px' }}
                    />
                </div>

                <p style={{ color: 'green' }}>{message}</p>

                {/* Form Card */}
                <div
                    style={{
                        width: '100%',
                        maxWidth: '500px',
                        backgroundColor: 'lightgray',
                        padding: '1.5em',
                        borderRadius: '10px',
                        boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
                        marginBottom: '2em'
                    }}
                >
                    <form onSubmit={handleSubmit}>
                        <label>Task ID:</label>
                        <input type="number" value={taskID} onChange={e => setTaskID(e.target.value)} required disabled={isEditing} style={inputStyle} />
                        <label>First Name:</label>
                        <input type="text" value={taskFName} onChange={e => setTaskFName(e.target.value)} required style={inputStyle} />
                        <label>Last Name:</label>
                        <input type="text" value={taskLName} onChange={e => setTaskLName(e.target.value)} required style={inputStyle} />
                        <label>Description:</label>
                        <input type="text" value={description} onChange={e => setDescription(e.target.value)} required style={inputStyle} />
                        <button
                            type="submit"
                            style={{
                                width: '100%',
                                padding: '10px',
                                marginTop: '10px',
                                backgroundColor: 'red',
                                color: 'blue',
                                border: 'none',
                                borderRadius: '5px',
                                fontWeight: 'bold',
                                cursor: 'pointer'
                            }}
                        >
                            {isEditing ? 'Update Task' : 'Submit'}
                        </button>
                    </form>
                </div>

                {/* Task Table */}
                <div
                    style={{
                        width: '100%',
                        maxWidth: '1000px',
                        backgroundColor: '#ffffff',
                        border: '1px solid #ccc',
                        borderRadius: '8px',
                        padding: '1em',
                        overflowX: 'auto'
                    }}
                >
                    <h2 style={{ marginBottom: '10px' }}>managment  List</h2>
                    <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                        <thead style={{ backgroundColor: 'black' }}>
                            <tr>
                                <th>Task ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {taskList.length > 0 ? (
                                taskList.map((task, index) => (
                                    <tr key={index}>
                                        <td>{task.TaskID}</td>
                                        <td>{task.TaskFname}</td>
                                        <td>{task.TaskLname}</td>
                                        <td>{task.Description}</td>
                                        <td>
                                            <button onClick={() => handleEdit(task)} style={{ marginRight: '5px' }}>Edit</button>
                                            <button onClick={() => handleDelete(task.TaskID)}>Delete</button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan="5" style={{ textAlign: 'center' }}>No tasks available</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Task;
