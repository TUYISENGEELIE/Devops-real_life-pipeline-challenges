import React, { useEffect, useState } from 'react';
import './App.css';

import Registration from './components/Registration';
import Login from './components/login'
import Home from './components/Dashbod'
import User from './components/User'
import Task from './components/Task'
import About from './components/About'

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={< Dashbod />} />
        <Route path="/home" element={<Dashbod />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/login" element={<Login />} />
        <Route path="/task" element={<Task />} />
        <Route path="/user" element={<User />} />
        <Route path="/About" element={<About />} />
      </Routes>
    </Router>
  );
}

export default App;
