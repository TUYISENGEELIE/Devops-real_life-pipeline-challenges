

const mysql = require('mysql');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'Devops_db'
});

// Connect to MySQL
connection.connect((err) => {
    if (err) {
        console.error(' MySQL Connection Failed:', err.message);
        return;
    }
    console.log('MySQL Connected Successfully');
});

module.exports = connection;
