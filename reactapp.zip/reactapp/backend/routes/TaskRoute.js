const express = require('express');
const router = express.Router();
const connection = require('../database/dbConnection');


connection.connect(function (err) {
    if (err) {
        console.log("Error in the connection");
        console.log(err);
    } else {

        // Ensure the table exists
        const createTableQuery = `
                    CREATE TABLE IF NOT EXISTS  (
                    TaskID INT PRIMARY KEY,
                    TaskFName VARCHAR(50),
                    TaskLName VARCHAR(50),
                    Description VARCHAR(255)
                    )
                    `;

        connection.query(createTableQuery, (err) => {
            if (err) console.error('Table creation error:', err.message);
            else console.log('task table ready.');
        });

    }
});
// Insert data
router.post('/insert', (req, res) => {
    const { TaskID, TaskFName, TaskLName, Description } = req.body;

    //console.log('check if there is a connection')
    //
    //console.log(req.body)

    if (!TaskID || !TaskFName || !TaskLName || !Description) {
        return res.status(400).send('Missing fields');
    }

    const insertQuery = `INSERT INTO task (TaskID, TaskFName, TaskLName, Description) VALUES (?,? ,? ,? )`;
    connection.query(insertQuery, [TaskID, TaskFName, TaskLName, Description], (err) => {
        if (err) {
            console.error('Insert error:', err.message);
            return res.status(500).send('Insert failed');
        }
        res.send('Task inserted successfully');
    });
});

//  Update data
router.put('/update/:TaskID', (req, res) => {
    const { TaskFName, TaskLName, Description } = req.body;
    const { TaskID } = req.params;

    //console.log(req.body)

    if (!TaskFName || !TaskLName || !Description) {
        return res.status(400).send('Missing fields for update');
    }

    const updateQuery = `UPDATE task SET TaskFname = ?, TaskLname = ?, Description = ? WHERE TaskID = ?`;
    connection.query(updateQuery, [TaskFName, TaskLName, Description, TaskID], (err, result) => {
        if (err) {
            console.error('Update error:', err.message);
            return res.status(500).send('Update failed');
        }
        if (result.affectedRows === 0) {
            return res.status(404).send('Task not found');
        }
        res.send('Task updated successfully');
    });
});



// Get all task
router.get('/task', (req, res) => {
    const getAllQuery = `SELECT * FROM task`;
    connection.query(getAllQuery, (err, results) => {
        if (err) {
            console.error('Get All error:', err.message);
            return res.status(500).send('Failed to retrieve tasks');
        }
        res.json(results);
    });
});

//  Delete data
router.delete('/delete/:TaskID', (req, res) => {
    const { TaskID } = req.params;
    const deleteQuery = `DELETE FROM task WHERE TaskID = ?`;
    connection.query(deleteQuery, [TaskID], (err, result) => {
        if (err) {
            console.error('Delete error:', err.message);
            return res.status(500).send('Delete failed');
        }
        if (result.affectedRows === 0) {
            return res.status(404).send('Task not found');
        }
        res.send('Task deleted successfully');
    });
});

module.exports = router;
