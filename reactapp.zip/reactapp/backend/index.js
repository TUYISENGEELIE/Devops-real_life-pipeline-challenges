const express = require('express');
const connection = require('./database/dbConnection');
const taskRoutes = require('./routes/DevopsRoute');
const app = express();
const PORT = 5000;

app.use(express.json());
var cors = require('cors')
app.use(cors());


app.use('/Devopstask', taskRoutes);

app.use('*', (request, response) => {
    response.send({ message: 'This is my backend app' });
});

app.listen(PORT, () => {
    console.log(`Application is running on port: ${PORT}`);
});